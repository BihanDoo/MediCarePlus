package view;

public class sendNotificationsToDoctors {
}
