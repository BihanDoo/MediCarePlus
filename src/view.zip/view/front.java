package view;

import javax.swing.*;

public class front extends JFrame {
    private JPanel panel1;
}
