package view;

import javax.swing.*;

public class GenerateReports extends JFrame {
    private JPanel GenerateReportsPane;

    GenerateReports(){
        setContentPane(GenerateReportsPane);
        setTitle("Generate Reports");
        setDefaultCloseOperation(HIDE_ON_CLOSE);
        setSize(600,550);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    static void main() {

    }
}
